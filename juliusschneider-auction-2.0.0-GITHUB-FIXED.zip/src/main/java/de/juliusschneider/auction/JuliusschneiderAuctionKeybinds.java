package de.juliusschneider.auction;

import com.mojang.blaze3d.platform.InputConstants;
import de.juliusschneider.auction.ui.JuliusschneiderAuctionScreen;
import de.juliusschneider.auction.ui.JuliusschneiderChangelogScreen;
import de.juliusschneider.auction.ui.JuliusschneiderBaseScreen;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class JuliusschneiderAuctionKeybinds {
    private static KeyMapping toggle;

    private JuliusschneiderAuctionKeybinds() {}

    public static void register() {
        KeyMapping.Category category = KeyMapping.Category.register(JuliusSchneiderAuction.id("main"));
        toggle = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key." + JuliusSchneiderAuction.MOD_ID + ".toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, category));
    }

    /** Pro Tick aufrufen. Schliessen im geoeffneten Screen erfolgt per ESC. */
    public static void poll(Minecraft mc) {
        if (toggle == null) return;
        while (toggle.consumeClick()) {
            if (mc.screen instanceof JuliusschneiderBaseScreen) mc.setScreen(null);
            else if (mc.screen == null) openMain(mc);
        }
    }

    /** Öffnet die Haupt-GUI; nach einem Update erscheint zuerst das Änderungsprotokoll. */
    public static void openMain(Minecraft mc) {
        var cfg = JuliusschneiderAuctionConfig.get();
        String v = JuliusschneiderChangelog.currentVersion();
        var main = new JuliusschneiderAuctionScreen();
        if (!v.equals(cfg.lastSeenVersion)) {
            cfg.lastSeenVersion = v;
            JuliusschneiderAuctionConfig.save();
            mc.setScreen(new JuliusschneiderChangelogScreen(main));
        } else {
            mc.setScreen(main);
        }
    }
}
