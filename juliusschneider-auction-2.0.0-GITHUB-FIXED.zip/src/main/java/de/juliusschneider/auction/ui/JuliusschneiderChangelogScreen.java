package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.JuliusschneiderChangelog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Änderungsprotokoll: eine Seite pro Version, neueste zuerst. */
public class JuliusschneiderChangelogScreen extends JuliusschneiderBaseScreen {
    private final Screen parent;
    private int page;

    public JuliusschneiderChangelogScreen(Screen parent) {
        super("JuliusSchneider Auction - Änderungen");
        this.parent = parent;
    }

    @Override
    protected void build() {
        int x = px + 14, w = pw - 28, n = JuliusschneiderChangelog.RELEASES.size();
        btn(x, py + 236, 40, 20, "<", MUTED, page > 0, () -> { page--; rebuildWidgets(); });
        btn(x + w - 40, py + 236, 40, 20, ">", MUTED, page < n - 1, () -> { page++; rebuildWidgets(); });
        btn(x, py + ph - 46, w, 28, "ZURÜCK", GOLD, this::onClose);
    }

    @Override
    protected void draw(GuiGraphicsExtractor g, int mx, int my) {
        var releases = JuliusschneiderChangelog.RELEASES;
        var r = releases.get(page);
        textScaled(g, "ÄNDERUNGEN", px + 14, py + 12, GOLD, 1.3f);
        textScaled(g, "VERSION " + r.version(), px + 14, py + 40, TEXT, 1.2f);
        if (r.version().equals(JuliusschneiderChangelog.currentVersion())) {
            String tag = "AKTUELL";
            panel(g, px + pw - 14 - width(tag) - 12, py + 40, width(tag) + 12, 14, mix(BG, GREEN, 0.25f), GREEN);
            text(g, tag, px + pw - 14 - width(tag) - 6, py + 43, GREEN);
        }
        int y = py + 66;
        for (String line : r.lines()) {
            text(g, "- " + trim(line, pw - 48), px + 18, y, TEXT);
            y += 14;
        }
        centered(g, "Seite " + (page + 1) + " / " + releases.size(), px + pw / 2, py + 242, MUTED);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
