package de.juliusschneider.auction.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

import java.text.NumberFormat;
import java.util.Locale;

/** Gemeinsame Zeichenhelfer, Farbschemata und Palette des JuliusSchneider-Auction-Looks. */
public final class JuliusschneiderUi {
    // Theme-abhängig (GOLD = Akzentfarbe des aktuellen Schemas)
    public static int BG = 0xF00D1117, PANEL = 0xD9161B22, PANEL_HI = 0xD9212A36, BORDER = 0xFF30363D, GOLD = 0xFFF5B83D;
    // Feste Farben
    public static final int GREEN = 0xFF3FB950, RED = 0xFFF85149, BLUE = 0xFF58A6FF;
    public static final int TEXT = 0xFFE6EDF3, MUTED = 0xFF8B949E;

    public static final String[] THEMES = {"GOLD", "OZEAN", "LILA", "TÜRKIS", "ROSA"};

    private JuliusschneiderUi() {}

    public static int themeAccent(String name) {
        return switch (name) {
            case "OZEAN" -> 0xFF5AB4FF;
            case "LILA" -> 0xFFB48CFF;
            case "TÜRKIS" -> 0xFF2DD4BF;
            case "ROSA" -> 0xFFFF7EB6;
            default -> 0xFFF5B83D;
        };
    }

    public static void applyTheme(String name) {
        if (name == null) name = "GOLD";
        switch (name) {
            case "OZEAN" -> set(0xF00A1018, 0xD9101C2C, 0xD91A2B40, 0xFF27415C, name);
            case "LILA" -> set(0xF0120D1A, 0xD91A1426, 0xD9261D38, 0xFF3E3158, name);
            case "TÜRKIS" -> set(0xF00B1416, 0xD9111E21, 0xD91A2C30, 0xFF284A4F, name);
            case "ROSA" -> set(0xF0170D14, 0xD9211420, 0xD92E1C2C, 0xFF4F2D45, name);
            default -> set(0xF00D1117, 0xD9161B22, 0xD9212A36, 0xFF30363D, "GOLD");
        }
    }

    private static void set(int bg, int panel, int panelHi, int border, String name) {
        BG = bg; PANEL = panel; PANEL_HI = panelHi; BORDER = border; GOLD = themeAccent(name);
    }

    public static Font font() { return Minecraft.getInstance().font; }
    public static int width(String s) { return font().width(s); }

    private static int inset(int row, int r) {
        double dy = r - row - 0.5;
        double dx = Math.sqrt(Math.max(0, r * (double) r - dy * dy));
        return (int) Math.round(r - dx);
    }

    /** Gefülltes Rechteck mit abgerundeten Ecken (ohne überlappende Zeilen, daher alpha-sicher). */
    public static void rounded(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, color); return; }
        for (int i = 0; i < r; i++) {
            int in = inset(i, r);
            g.fill(x + in, y + i, x + w - in, y + i + 1, color);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void panelR(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int fill, int border) {
        rounded(g, x, y, w, h, r, border);
        rounded(g, x + 1, y + 1, w - 2, h - 2, Math.max(1, r - 1), fill);
    }

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int fill, int border) {
        panelR(g, x, y, w, h, Math.min(w, h) < 16 ? 2 : 4, fill, border);
    }

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(font(), s, x, y, color, true);
    }

    public static void textRight(GuiGraphicsExtractor g, String s, int rightX, int y, int color) {
        text(g, s, rightX - width(s), y, color);
    }

    public static void centered(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        text(g, s, cx - width(s) / 2, y, color);
    }

    public static void textScaled(GuiGraphicsExtractor g, String s, int x, int y, int color, float scale) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.text(font(), s, 0, 0, color, true);
        g.pose().popMatrix();
    }

    public static void item(GuiGraphicsExtractor g, ItemStack stack, int x, int y, float scale) {
        if (stack.isEmpty()) return;
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.item(stack, 0, 0);
        g.itemDecorations(font(), stack, 0, 0);
        g.pose().popMatrix();
    }

    /** Durchgehender, abgerundeter Balken. */
    public static void bar(GuiGraphicsExtractor g, int x, int y, int w, int h, double frac, int color) {
        int r = Math.min(4, h / 2);
        rounded(g, x, y, w, h, r, 0xFF21262D);
        int fw = (int) Math.round(w * Math.max(0, Math.min(1, frac)));
        if (fw > 0) rounded(g, x, y, fw, h, Math.min(r, fw / 2), color);
    }

    /** Konfetti für die Gewinner-Animation (t = ms seit Ende). */
    public static void confetti(GuiGraphicsExtractor g, int x, int y, int w, int h, long t) {
        if (t < 0 || t > 4500 || w < 10 || h < 10) return;
        float fade = t > 3500 ? 1f - (t - 3500) / 1000f : 1f;
        int[] cols = {GOLD, 0xFFFFFFFF, GREEN, BLUE, RED};
        for (int i = 0; i < 48; i++) {
            int seed = i * 7919 + 13;
            int cx = x + Math.floorMod(seed * 31, w);
            int speed = 40 + Math.floorMod(seed, 60);
            int cy = y + (int) Math.floorMod((long) (t * speed / 1000) + Math.floorMod(seed * 17, h), (long) h);
            int a = (int) (255 * fade);
            g.fill(cx, cy, cx + 2, cy + 3, (cols[i % 5] & 0x00FFFFFF) | (a << 24));
        }
    }

    public static int mix(int a, int b, float t) {
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, aa = a >>> 24;
        int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255, ba = b >>> 24;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static String money(long v) {
        return "$" + NumberFormat.getIntegerInstance(Locale.GERMANY).format(v);
    }

    public static String time(long ms) {
        long s = (ms + 999) / 1000;
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    public static String trim(String s, int maxPx) {
        if (width(s) <= maxPx) return s;
        while (s.length() > 1 && width(s + "...") > maxPx) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    /** Animierter Button mit abgerundeten Ecken. */
    public static final class Btn {
        public final int x, y, w, h;
        public final String label;
        public final int color;
        public final boolean enabled;
        public final Runnable action;

        public Btn(int x, int y, int w, int h, String label, int color, boolean enabled, Runnable action) {
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.label = label; this.color = color; this.enabled = enabled; this.action = action;
        }

        public boolean hit(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }

        public void draw(GuiGraphicsExtractor g, int mx, int my) {
            boolean hover = enabled && hit(mx, my);
            int base = enabled ? color : 0xFF30363D;
            int fill = mix(0xFF161B22, base, hover ? 0.55f : 0.28f);
            panel(g, x, y, w, h, fill, hover ? mix(base, 0xFFFFFFFF, 0.3f) : base);
            centered(g, label, x + w / 2, y + (h - 8) / 2, enabled ? TEXT : MUTED);
        }
    }
}
