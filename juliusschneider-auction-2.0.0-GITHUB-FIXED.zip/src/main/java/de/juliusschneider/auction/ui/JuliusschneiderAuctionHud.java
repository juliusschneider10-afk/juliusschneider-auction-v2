package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.*;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Kompaktes Mini-HUD. Laeuft unabhaengig von der Haupt-GUI. */
public final class JuliusschneiderAuctionHud {
    private static final int W = 140;

    public void extract(GuiGraphicsExtractor g, DeltaTracker dt) {
        var cfg = JuliusschneiderAuctionConfig.get();
        var m = JuliusschneiderAuctionManager.get();
        if (!cfg.hudEnabled) return;
        if (Minecraft.getInstance().screen instanceof JuliusschneiderBaseScreen) return;
        boolean running = m.state() == JuliusschneiderAuctionState.RUNNING;
        if (!running && !m.resultHudVisible()) return;

        int h = running ? 74 : 62;
        float s = cfg.hudScale;
        int sw = g.guiWidth(), sh = g.guiHeight(), margin = 6;
        float pw = W * s, ph = h * s;
        float x = cfg.hudPosition.endsWith("LEFT") ? margin : sw - pw - margin;
        float y = cfg.hudPosition.startsWith("TOP") ? margin : sh - ph - margin;

        long endedFor = System.currentTimeMillis() - m.endedAtMs();
        int hudBorder = (!running && cfg.winnerAnimation && m.winner() != null && endedFor < 4000)
                ? mix(BORDER, GOLD, (float) (0.5 + 0.5 * Math.sin(endedFor / 180.0))) : BORDER;
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(s, s);
        panel(g, 0, 0, W, h, (BG & 0x00FFFFFF) | 0xCC000000, hudBorder);
        g.fill(5, 1, W - 5, 3, GOLD);
        text(g, "JULIUSSCHNEIDER AUCTION", 6, 6, GOLD);
        var leader = running ? m.leader() : m.winner();
        if (running) {
            long rem = m.remainingMs();
            boolean urgent = rem <= 10_000;
            text(g, trim(m.itemName(), 80), 6, 18, TEXT);
            int col = urgent ? ((System.currentTimeMillis() / 300) % 2 == 0 ? RED : TEXT) : TEXT;
            textRight(g, time(rem), W - 6, 18, col);
            bar(g, 6, 29, W - 12, 4, m.progress(), urgent ? RED : GOLD);
            text(g, "FÜHREND", 6, 37, MUTED);
            text(g, leader == null ? "-" : trim(leader.player(), 100), 6, 47, TEXT);
            text(g, leader == null ? "Min " + money(m.minBid()) : money(leader.amount()), 6, 59, leader == null ? MUTED : GOLD);
            var recent = m.recentBids();
            if (!recent.isEmpty()) textRight(g, "Letztes: " + money(recent.get(0).amount()), W - 6, 59, MUTED);
        } else {
            text(g, "BEENDET", 6, 18, RED);
            text(g, m.cancelled() ? "ABGEBROCHEN" : (leader == null ? "KEINE GEBOTE" : "GEWINNER"), 6, 32, MUTED);
            if (leader != null) {
                text(g, trim(leader.player(), 120), 6, 42, TEXT);
                text(g, money(leader.amount()), 6, 52, GREEN);
            }
        }
        g.pose().popMatrix();
    }
}
