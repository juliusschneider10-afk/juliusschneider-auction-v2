package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.JuliusschneiderHistory;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Alle bisherigen Auktionen. */
public class JuliusschneiderHistoryScreen extends JuliusschneiderPagedListScreen {
    private static final SimpleDateFormat DATE = new SimpleDateFormat("dd.MM. HH:mm");
    private final List<JuliusschneiderHistory.Entry> list = JuliusschneiderHistory.newestFirst();

    public JuliusschneiderHistoryScreen(Screen parent) { super("JuliusSchneider Auction - Verlauf", parent); }

    @Override protected int size() { return list.size(); }
    @Override protected String heading() { return "AUKTIONS-VERLAUF"; }
    @Override protected String emptyText() { return "Noch keine Auktionen gespeichert"; }

    @Override
    protected String subtitle() {
        return "Auktionen: " + JuliusschneiderHistory.count() + "  |  Einnahmen gesamt: " + money(JuliusschneiderHistory.totalRevenue());
    }

    @Override
    protected void drawRow(GuiGraphicsExtractor g, int i, int x, int y, int w) {
        var e = list.get(i);
        panel(g, x, y, w, 22, PANEL, BORDER);
        text(g, DATE.format(new Date(e.endedAt)), x + 6, y + 3, MUTED);
        text(g, trim(e.item + " x" + e.count + (e.test ? "  [TEST]" : ""), w - 190), x + 80, y + 3, TEXT);
        String res;
        int col;
        if (e.cancelled) { res = "Abgebrochen"; col = RED; }
        else if (e.winner == null) { res = "Keine Gebote"; col = MUTED; }
        else { res = e.winner + "  " + money(e.winningBid); col = GREEN; }
        text(g, trim(res, w - 12), x + 6, y + 12, col);
        textRight(g, "Einnahmen " + money(e.revenue), x + w - 6, y + 3, GOLD);
    }
}
