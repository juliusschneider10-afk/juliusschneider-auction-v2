package de.juliusschneider.auction.ui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.Screen;

import java.util.ArrayList;
import java.util.List;

/** Basis fuer alle JuliusSchneider-Screens: dunkles Panel, eigene Buttons, Statuszeile. */
public abstract class JuliusschneiderBaseScreen extends Screen {
    protected final List<JuliusschneiderUi.Btn> buttons = new ArrayList<>();
    protected int px, py, pw, ph;
    protected String message = "";
    protected int messageColor = JuliusschneiderUi.RED;
    protected long messageUntil;

    protected JuliusschneiderBaseScreen(String title) { super(Component.literal(title)); }

    @Override
    protected void init() {
        pw = Math.min(440, width - 12);
        ph = Math.min(316, height - 8);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        buttons.clear();
        build();
    }

    protected abstract void build();
    protected abstract void draw(GuiGraphicsExtractor g, int mx, int my);
    protected void backdropExtras(GuiGraphicsExtractor g) {}

    protected void btn(int x, int y, int w, int h, String label, int color, Runnable action) {
        buttons.add(new JuliusschneiderUi.Btn(x, y, w, h, label, color, true, action));
    }

    protected void btn(int x, int y, int w, int h, String label, int color, boolean enabled, Runnable action) {
        buttons.add(new JuliusschneiderUi.Btn(x, y, w, h, label, color, enabled, action));
    }

    protected void flash(String msg, boolean error) {
        message = msg == null ? "" : msg;
        messageColor = error ? JuliusschneiderUi.RED : JuliusschneiderUi.GREEN;
        messageUntil = System.currentTimeMillis() + 4000;
    }

    /** Hintergrund + Panel; wird von der Screen-Pipeline vor den Widgets gezeichnet. */
    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0xB0060810);
        JuliusschneiderUi.panelR(g, px, py, pw, ph, 6, JuliusschneiderUi.BG, JuliusschneiderUi.BORDER);
        g.fill(px + 8, py + 1, px + pw - 8, py + 3, JuliusschneiderUi.GOLD);
        backdropExtras(g);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        draw(g, mx, my);
        for (var b : buttons) b.draw(g, mx, my);
        if (!message.isEmpty() && System.currentTimeMillis() < messageUntil)
            JuliusschneiderUi.centered(g, message, px + pw / 2, py + ph - 62, messageColor);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            for (var b : new ArrayList<>(buttons)) {
                if (b.enabled && b.hit(event.x(), event.y())) { b.action.run(); return true; }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
