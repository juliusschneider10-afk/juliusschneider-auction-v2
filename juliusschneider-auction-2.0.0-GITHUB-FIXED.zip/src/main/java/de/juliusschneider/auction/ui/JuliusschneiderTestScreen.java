package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Entwickler-Testmenue: simulierte Gebote (getrennt vom echten Payment). */
public class JuliusschneiderTestScreen extends JuliusschneiderBaseScreen {
    private final Screen parent;
    private final JuliusschneiderTestBidProvider provider = JuliusschneiderTestBidProvider.INSTANCE;
    private EditBox nameBox, amountBox;

    public JuliusschneiderTestScreen(Screen parent) {
        super("JuliusSchneider Auction - Testmenue");
        this.parent = parent;
    }

    @Override
    protected void build() {
        int x = px + 14, w = pw - 28, bw = (w - 6) / 2;
        btn(x, py + 52, bw, 24, "TESTGEBOT", BLUE, () -> {
            var r = provider.randomBid(); flash(r.message(), !r.ok()); });
        btn(x + bw + 6, py + 52, w - bw - 6, 24, "5 TESTGEBOTE", BLUE, () -> {
            int ok = provider.randomBids(5); flash(ok + " Testgebote registriert", ok == 0); });

        nameBox = new EditBox(font, x, py + 112, bw, 18, Component.literal("Spieler"));
        nameBox.setMaxLength(16);
        nameBox.setValue("Notch");
        addRenderableWidget(nameBox);
        amountBox = new EditBox(font, x + bw + 6, py + 112, w - bw - 6, 18, Component.literal("Betrag"));
        amountBox.setMaxLength(20);
        amountBox.setFilter(s -> s.matches("[0-9.,kKmMbB$ ]*"));
        amountBox.setValue("1m");
        addRenderableWidget(amountBox);
        btn(x, py + 140, w, 24, "GEBOT SENDEN", GREEN, () -> {
            var amount = JuliusschneiderAmountParser.parse(amountBox.getValue());
            if (amount.isEmpty()) { flash("Ungueltiger Betrag", true); return; }
            var r = provider.bid(nameBox.getValue().trim(), amount.getAsLong());
            flash(r.message(), !r.ok());
        });
        btn(x, py + ph - 46, w, 28, "ZURÜCK", GOLD, this::onClose);
    }

    @Override
    protected void draw(GuiGraphicsExtractor g, int mx, int my) {
        textScaled(g, "TEST-MENÜ", px + 14, py + 12, GOLD, 1.3f);
        text(g, "ZUFALLSGEBOTE", px + 14, py + 40, MUTED);
        text(g, "EIGENES TESTGEBOT (Spieler / Betrag, z. B. 1.5m)", px + 14, py + 100, MUTED);
        var l = JuliusschneiderAuctionManager.get().leader();
        text(g, "Führend: " + (l == null ? "-" : l.player() + "  " + money(l.amount())), px + 14, py + 176, TEXT);
        text(g, "Testgebote sind nur zum Ausprobieren.", px + 14, py + 190, MUTED);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
