package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.JuliusschneiderChatPaymentProvider;
import de.juliusschneider.auction.JuliusschneiderPaymentLog;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Zahlungslog + Ansicht der letzten Chat-Zeilen mit "$" (zur Fehlersuche der Erkennung). */
public class JuliusschneiderPaymentLogScreen extends JuliusschneiderPagedListScreen {
    private static final SimpleDateFormat DATE = new SimpleDateFormat("dd.MM. HH:mm:ss");
    private boolean raw;

    public JuliusschneiderPaymentLogScreen(Screen parent) { super("JuliusSchneider Auction - Zahlungslog", parent); }

    private List<JuliusschneiderPaymentLog.Entry> payments() { return JuliusschneiderPaymentLog.newestFirst(); }
    private List<String> lines() { return JuliusschneiderChatPaymentProvider.INSTANCE.recentRaw(); }

    @Override protected int size() { return raw ? lines().size() : payments().size(); }
    @Override protected String heading() { return raw ? "CHAT-ZEILEN MIT $" : "ZAHLUNGSLOG"; }
    @Override protected String subtitle() {
        return raw ? "Letzte Server-Meldungen mit $ (zur Fehlersuche der Erkennung)" : "Alle erkannten Zahlungen (neueste zuerst)";
    }
    @Override protected String emptyText() { return raw ? "Noch keine Zeilen mit $ empfangen" : "Noch keine Zahlungen erkannt"; }
    @Override protected String extraLabel() { return raw ? "ZAHLUNGEN ANZEIGEN" : "CHAT-ZEILEN ANZEIGEN"; }
    @Override protected void onExtra() { raw = !raw; }

    @Override
    protected void drawRow(GuiGraphicsExtractor g, int i, int x, int y, int w) {
        panel(g, x, y, w, 22, PANEL, BORDER);
        if (raw) {
            text(g, trim(lines().get(i), w - 12), x + 6, y + 7, TEXT);
            return;
        }
        var e = payments().get(i);
        text(g, DATE.format(new Date(e.time)) + "  " + trim(e.player, 110), x + 6, y + 3, TEXT);
        textRight(g, money(e.amount), x + w - 6, y + 3, GOLD);
        text(g, trim(e.result, w - 12), x + 6, y + 12, e.result.startsWith("Gebot") ? GREEN : MUTED);
    }
}
