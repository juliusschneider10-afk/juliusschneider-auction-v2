package de.juliusschneider.auction;

import java.math.BigDecimal;
import java.util.OptionalLong;

/** Parser fuer Betraege: 500000, 500.000, $1k, 1.5m, 2b. */
public final class JuliusschneiderAmountParser {
    private JuliusschneiderAmountParser() {}

    public static OptionalLong parse(String input) {
        if (input == null) return OptionalLong.empty();
        String s = input.trim().toLowerCase().replace("$", "").replace(" ", "").replace("_", "");
        if (s.isEmpty()) return OptionalLong.empty();
        long mult = 1;
        char last = s.charAt(s.length() - 1);
        if (last == 'k' || last == 'm' || last == 'b') {
            mult = last == 'k' ? 1_000L : last == 'm' ? 1_000_000L : 1_000_000_000L;
            s = s.substring(0, s.length() - 1);
            s = s.replace(',', '.');
        } else {
            s = s.replace(".", "").replace(",", "");
        }
        try {
            BigDecimal v = new BigDecimal(s).multiply(BigDecimal.valueOf(mult));
            if (v.signum() < 0) return OptionalLong.empty();
            return OptionalLong.of(v.longValueExact());
        } catch (RuntimeException e) {
            return OptionalLong.empty();
        }
    }
}
