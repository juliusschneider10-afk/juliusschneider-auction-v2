package de.juliusschneider.auction;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Optionaler Provider: erkennt eingehende Zahlungen anhand zweier konfigurierbarer Regex
 * (je mit den Gruppen "player" und "amount") in SERVER-Systemnachrichten. Standardmäßig AUS.
 * Jede erkannte Zahlung landet im Zahlungslog.
 */
public final class JuliusschneiderChatPaymentProvider implements JuliusschneiderBidProvider {
    public static final JuliusschneiderChatPaymentProvider INSTANCE = new JuliusschneiderChatPaymentProvider();

    public record Parsed(String player, long amount) {}

    private final Map<String, Pattern> cache = new HashMap<>();
    private final Deque<String> recentRaw = new ArrayDeque<>();
    private String lastLine = "";
    private long lastLineMs;

    @Override public String id() { return "chat-pay"; }

    public static void register() {
        JuliusschneiderAuctionManager.get().registerProvider(INSTANCE);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) INSTANCE.onMessage(message.getString());
        });
    }

    /** Letzte Systemzeilen mit "$" (zur Fehlersuche), neueste zuerst. */
    public List<String> recentRaw() { return new ArrayList<>(recentRaw); }

    private Pattern pattern(String rx) {
        if (rx == null || rx.isBlank()) return null;
        try {
            return cache.computeIfAbsent(rx, Pattern::compile);
        } catch (PatternSyntaxException e) {
            return null;
        }
    }

    public Optional<Parsed> parse(String line) {
        var cfg = JuliusschneiderAuctionConfig.get();
        for (String rx : new String[]{cfg.paymentRegex, cfg.paymentRegexAlt}) {
            Pattern p = pattern(rx);
            if (p == null) continue;
            Matcher m = p.matcher(line);
            if (!m.find()) continue;
            try {
                String player = m.group("player");
                OptionalLong amount = JuliusschneiderAmountParser.parse(m.group("amount"));
                if (player != null && amount.isPresent() && amount.getAsLong() >= 1)
                    return Optional.of(new Parsed(player, amount.getAsLong()));
            } catch (IllegalArgumentException ignored) { // Gruppen fehlen in der Regex
            }
        }
        return Optional.empty();
    }

    public void onMessage(String line) {
        if (line.indexOf('$') >= 0) {
            recentRaw.addFirst(line);
            while (recentRaw.size() > 40) recentRaw.removeLast();
        }
        var cfg = JuliusschneiderAuctionConfig.get();
        if (!cfg.paymentDetection) return;
        var parsed = parse(line);
        if (parsed.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (line.equals(lastLine) && now - lastLineMs < 800) return; // doppelte Meldung
        lastLine = line;
        lastLineMs = now;
        var mc = Minecraft.getInstance();
        if (mc.player != null && parsed.get().player().equalsIgnoreCase(mc.player.getName().getString())) return;
        var mgr = JuliusschneiderAuctionManager.get();
        String name = parsed.get().player();
        long amount = parsed.get().amount();
        if (mgr.state() != JuliusschneiderAuctionState.RUNNING) {
            JuliusschneiderPaymentLog.add(name, amount, "Keine laufende Auktion - nicht gewertet");
            return;
        }
        var result = mgr.submitBid(name, amount, id());
        JuliusschneiderPaymentLog.add(name, amount, result.ok() ? "Gebot gewertet" : "Abgelehnt: " + result.message());
        if (!result.ok())
            JuliusschneiderAuctionManager.feedback("Zahlung von " + name + " (" + amount + ") nicht gewertet: " + result.message());
    }
}
