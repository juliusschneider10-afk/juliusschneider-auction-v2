package de.juliusschneider.auction;

/** Ein registriertes Gebot. id steigt streng monoton (Reihenfolge). */
public record JuliusschneiderBid(long id, String player, long amount, long timeMs, String source) {}
