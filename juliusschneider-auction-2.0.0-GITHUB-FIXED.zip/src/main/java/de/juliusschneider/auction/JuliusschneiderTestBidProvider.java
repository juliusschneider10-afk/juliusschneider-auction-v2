package de.juliusschneider.auction;

import java.util.concurrent.ThreadLocalRandom;

/** Entwickler-Provider: simuliert Gebote. Strikt getrennt von echtem Payment. */
public final class JuliusschneiderTestBidProvider implements JuliusschneiderBidProvider {
    public static final JuliusschneiderTestBidProvider INSTANCE = new JuliusschneiderTestBidProvider();
    private static final String[] NAMES = {"Alex", "Steve", "Notch", "Herobrine", "Luna", "Kai", "Mia", "Finn"};

    @Override public String id() { return "test"; }

    public JuliusschneiderAuctionManager.BidResult bid(String player, long amount) {
        return JuliusschneiderAuctionManager.get().submitBid(player, amount, id());
    }

    /** Ein zufaelliges Gebot knapp ueber dem aktuellen Leader. */
    public JuliusschneiderAuctionManager.BidResult randomBid() {
        var m = JuliusschneiderAuctionManager.get();
        long base = Math.max(m.minBid(), m.leader() == null ? 0 : m.leader().amount());
        long step = Math.max(1, base / 10);
        long amount = base + step + ThreadLocalRandom.current().nextLong(step + 1);
        return bid(NAMES[ThreadLocalRandom.current().nextInt(NAMES.length)], amount);
    }

    public int randomBids(int count) {
        int ok = 0;
        for (int i = 0; i < count; i++) if (randomBid().ok()) ok++;
        return ok;
    }
}
