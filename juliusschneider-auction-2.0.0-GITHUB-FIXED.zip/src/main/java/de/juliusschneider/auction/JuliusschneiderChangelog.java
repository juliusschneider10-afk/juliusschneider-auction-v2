package de.juliusschneider.auction;

import net.fabricmc.loader.api.FabricLoader;

import java.util.List;

/** Änderungsprotokoll, das direkt in der Mod angezeigt wird. Neueste Version zuerst. */
public final class JuliusschneiderChangelog {
    public record Release(String version, List<String> lines) {}

    public static final List<Release> RELEASES = List.of(
            new Release("2.0.0", List.of(
                    "Hugo SMP: Zahlungserkennung (Du hast $X von Name erhalten)",
                    "Anti-Sniping: im Setup schaltbar, Werte in den Einstellungen",
                    "Auktions-Verlauf (Button VERLAUF), dauerhaft gespeichert",
                    "Zahlungslog (Button LOG) inkl. Chat-Zeilen zur Fehlersuche",
                    "Farbschemata: Gold, Ozean, Lila, Türkis, Rosa",
                    "Gewinner-Animation und Gewinner-Sound (abschaltbar)",
                    "Einstellungen in drei Reiter aufgeteilt",
                    "Standard-Laufzeit im Setup: 45 Sekunden",
                    "Richtige Umlaute in der ganzen Oberfläche",
                    "Rückzahlungen entfernt",
                    "Neu: Änderungsprotokoll direkt in der Mod (Button NEUES)")),
            new Release("1.1.0", List.of(
                    "Abgerundete Ecken im ganzen Design",
                    "Durchgehender Zeitbalken statt unterteiltem Balken",
                    "Item aus der Hand wird automatisch übernommen",
                    "Neues Test-Menü (Testgebote nicht mehr im Hauptmenü)",
                    "HUD an/aus nur noch in den Einstellungen",
                    "Button -10 SEK aus dem Hauptmenü entfernt")),
            new Release("1.0.0", List.of(
                    "Erste Version: Auktionen, GUI, Mini-HUD, Werbung, Testsystem")));

    private JuliusschneiderChangelog() {}

    public static String currentVersion() {
        return FabricLoader.getInstance().getModContainer(JuliusSchneiderAuction.MOD_ID)
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("2.0.0");
    }
}
