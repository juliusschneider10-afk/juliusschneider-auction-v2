# JuliusSchneider Auction (Fabric, Minecraft 26.1.2)

Clientseitiges Auktionssystem: Setup-/Live-GUI, Mini-HUD, Werbung, Testsystem, vorbereitete Payment-Schnittstelle.

## Build
Java 25 + Gradle 9.4.1 noetig. Einmalig den Wrapper erzeugen: `gradle wrapper --gradle-version 9.4.1`
(oder gradlew/gradle-wrapper.jar aus der Fabric-Beispielmod kopieren). Dann `./gradlew build` -> `build/libs/`.
Versionen siehe gradle.properties (nach https://fabricmc.net/develop/ pruefen).

## Bedienung
- Taste **J** (aenderbar in Steuerung > JuliusSchneider Auction) oeffnet die GUI, ESC schliesst.
- Commands: `/juliusschneider auction open|start|end|reset|status|skip <sek>|testbid <spieler> <betrag>|testbids <anzahl>`
- Config: `config/juliusschneider_auction.json`
- Echte Payments: `JuliusschneiderBidProvider` implementieren, in `JuliusschneiderAuctionManager.registerProvider` anmelden und Gebote per `submitBid(...)` melden.

## Zahlungserkennung (ohne Vault, da fremder Server)
- Einstellungen > Reiter AUKTION > ZAHLUNGSERKENNUNG: AN. Die Mod wertet Server-Systemnachrichten per Regex aus
  (`paymentRegex` / `paymentRegexAlt` in der Config, Gruppen `player` und `amount`).
- Hugo SMP (deutsch): `[Hugo SMP] Du hast $1 von Name erhalten`.
- Regex testen: `/juliusschneider auction paytest <Beispielzeile>`; setzen: `/juliusschneider auction payregex <regex>`.
- Button LOG: erkannte Zahlungen und (zur Fehlersuche) die letzten Chat-Zeilen mit $.
- Das Item musst du dem Gewinner selbst übergeben, Geld wird nie automatisch gesendet.

## GitHub Build

Dieses Projekt ist bereits als direkt baubares Gradle-Projekt eingerichtet.

1. Lade **den Inhalt dieser ZIP** in dein GitHub-Repository hoch (nicht die ZIP-Datei selbst als einziges Repository-Inhalt).
2. Die Datei `.github/workflows/build.yml` startet den Build automatisch bei einem Push.
3. Nach erfolgreichem Build findest du unter **Actions → Build mod → Artifacts** die fertige `juliusschneider-auction-mod`-ZIP mit der JAR-Datei.
4. Der Build verwendet Minecraft 26.1.2, Java 25, Fabric Loader 0.19.2 und Fabric API 0.146.1+26.1.2.

