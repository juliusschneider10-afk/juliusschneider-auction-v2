# Changelog

## 2.0.0
- Hugo SMP: Zahlungserkennung für "[Hugo SMP] Du hast $1 von Name erhalten"
- Anti-Sniping (im Setup schaltbar; Fenster/Zielzeit in den Einstellungen)
- Auktions-Verlauf (Button VERLAUF) und Zahlungslog (Button LOG)
- Farbschemata: Gold, Ozean, Lila, Türkis, Rosa
- Gewinner-Animation und Gewinner-Sound (abschaltbar)
- Einstellungen in drei Reiter aufgeteilt
- Standard-Laufzeit im Setup: 45 Sekunden
- Richtige Umlaute in der Oberfläche
- Rückzahlungen entfernt
- Änderungsprotokoll direkt in der Mod (Button NEUES, erscheint nach einem Update automatisch)

## 1.1.0
- Abgerundete Ecken, durchgehender Zeitbalken, automatische Item-Übernahme, Test-Menü, HUD-Schalter nur in den Einstellungen

## 1.0.0
- Erste Version
